<?php
// Register the theme's menus
function assignmentone_theme_setup() {
    register_nav_menus( array(
        'header' => 'Header menu',
        'footer' => 'Footer menu'
    ) );
}
add_action( 'after_setup_theme', 'assignmentone_theme_setup');

//add image support for posts
add_theme_support( 'post-thumbnails' );
//custom plugin
 function Chasing_The_Dream_init(){
    $args = array(
        'label'=>'Chasing The Dream',
        'public'=>true,
        'show_ui'=>true,
        'capability_type'=>'post',
        'hierarchical'=>'false',
        'query_var'=>true,
        'menu_icon'=>'dashicons-album',
        'taxonomies' => array('category'),
        'supports'=> array(
            'title',
            'editor',
            'excerpts',
            'thumbnail',
            'author',
            'post-formats',
            'page-attributes',
        )
    );
    register_post_type('chasingTheDream', $args);
}
add_action('init','Chasing_The_Dream_init');
// Create custom shortcode for custom plugin
function Chasing_The_Dream__shortcode(){
  $query = new WP_Query(array('post_type' => 'chasingTheDream', 'post_per_page' => 3, 'order' => 'asc'));
  // query and loop through posts
  while ($query -> have_posts()) : $query-> the_post(); ?>
  <!-- display posts -->
  <div class="Chasing-The-Dream-container">
  <div>
      <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
    </div>
    <div>
      <h4><?php the_title(); ?></h4>
      <?php the_content(); ?>
      <p><a href="<?php the_permalink(); ?>">Learn More</a></p>
    </div>
  </div>
  <?php wp_reset_postdata(); ?>
  <?php
    endwhile;
    wp_reset_postdata();
}
// register shortcode
add_shortcode('chasingTheDream', 'Chasing_The_Dream__shortcode'); 
?>
