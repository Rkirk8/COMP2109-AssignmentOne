<!DOCTYPE html>
<html lang="<?php language_attributes(); ?>">
<!--meta data-->
    <head>
        <meta charset="<?php bloginfo('charset'); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php wp_head(); ?>
        <!-- add custom CSS -->
        <link rel="stylesheet" href="<?php echo esc_url( home_url('wp-content/themes/assignmentone/includes/css/stylesheet.css')); ?>">
        <!-- add custom JS -->
        <!-- add fonts -->
    </head>
<!-- Shared header-->
    <body <?php body_class();?>>
        <header>
            <div>
                <a href="<?php echo esc_url( home_url() );?>">
                    <img src="<?php echo esc_url( home_url( 'wp-content/uploads/2024/02/logo.png'));?>" alt="Header Logo says 'Rielly Kirk Assignment One' on top of a big blue octagon">
                </a>
            </div>
        <!--global Nav-->
            <nav>
                <?php
                wp_nav_menu( array(
                    'menu'=>"main",
                    "theme_location"=>'',
                    'depth'=>2,
                    'fallback_cb'=>false
                ));
                ?>
            </nav>
        </header>