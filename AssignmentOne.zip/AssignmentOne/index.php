<?php
// backup page if home.php fails
get_header();?>
<?php
// get the get_footer
get_footer();?>