<?php 
/*
 * Template Name: Single Post
 * Template Post Type: post
 */
get_header();
/* get featured image as masthead*/
$featuredImage = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'full');
?>
<section class="post-masthead" style="background-image: url('<?php echo $featuredImage[0]; ?>');">
  <div>
    <h1><?php the_title(); ?></h1>
  </div>
</section>
<!-- single post content -->
<div>
    <?php the_content(); ?>
</div>
<section>
    <!-- other posts -->
    <div>
        <h2>Other Posts</h2>
        <?php
        // query and loop through posts
        $query = new WP_Query( array(
            'post_type' => 'post',
            'posts_per_page' => 3,
        ) );
        while ( $query->have_posts() ) : $query->the_post();
        ?>
        <!-- display posts -->
        <article>
            <a href="<?php the_permalink(); ?>">
                <?php the_post_thumbnail(); ?>
                <?php the_title(); ?>
            </a>
            <?php the_excerpt(__('(Read More)')); ?>
        </article>
        <!-- end posts -->
        <?php endwhile; ?>
        <?php
        wp_reset_postdata();
        ?>
    </div>
</section>
<?php
get_footer();
?>
