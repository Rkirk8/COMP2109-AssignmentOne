<?php
/** 
 * Template Name: Homepage Advanced custom fields
 * Template Post Type: page
 */
get_header();
?>
<main>
  <section class="masthead" style="background-image: url('http://localhost:10010/wp-content/uploads/2024/02/sglx4br8pmk01wl5.jpg')">
    <div>
      <h1><?php echo wp_kses_post(get_field('page_title')); ?></h1>
    </div>
  </section>
  <section class="home-intro">
      <h2><?php echo wp_kses_post(get_field('row_title')); ?></h2>
      <p><?php echo wp_kses_post(get_field('row_one_text')); ?></p>
  </section>
  </section>
</main>
<?php
get_footer();
?>